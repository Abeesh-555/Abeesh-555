$(window).scroll(function() {
    if ($(this).scrollTop() > 1){  
        $('header').addClass("sticky");
      }
      else{
        $('header').removeClass("sticky");
      }
    });



    $(document).ready(function(){ 
        var touch 	= $('#resp-menu');
        var menu 	= $('.menu');
     
        $(touch).on('click', function(e) {
            e.preventDefault();
            menu.slideToggle();
        });
        
        $(window).resize(function(){
            var w = $(window).width();
            if(w > 767 && menu.is(':hidden')) {
                menu.removeAttr('style');
            }
        });
        
    });


    var btn = $('#top');

    $(window).scroll(function() {
      if ($(window).scrollTop() > 300) {
        btn.addClass('visible');
      } else {
        btn.removeClass('visible');
      }
    });
    
    btn.on('click', function(e) {
      e.preventDefault();
      $('html, body').animate({scrollTop:0}, '300');
    });
    

    $(".counter").each(function () {
        var $this = $(this),
          countTo = $this.attr("data-countto");
        countDuration = parseInt($this.attr("data-duration"));
        $({ counter: $this.text() }).animate(
          {
            counter: countTo
          },
          {
            duration: countDuration,
            easing: "linear",
            step: function () {
              $this.text(Math.floor(this.counter));
            },
            complete: function () {
              $this.text(this.counter);
            }
          }
        );
      });
      


      $(document).ready(function() {
        $('.acc-container .acc:nth-child(1) .acc-head').addClass('active');
        $('.acc-container .acc:nth-child(1) .acc-content').slideDown();
        $('.acc-head').on('click', function() {
            if($(this).hasClass('active')) {
              $(this).siblings('.acc-content').slideUp();
              $(this).removeClass('active');
            }
            else {
              $('.acc-content').slideUp();
              $('.acc-head').removeClass('active');
              $(this).siblings('.acc-content').slideToggle();
              $(this).toggleClass('active');
            }
        });     
        });



        // $(document).ready(function() {
        //   $(".accordion").on("click", function() {
        //     $(this).toggleClass("active");
        //     $(this).next().slideToggle(200);
        //   });
        // });
        
        $('.accordion__header').click(function(e) {
          e.preventDefault();
          var currentIsActive = $(this).hasClass('is-active');
          $(this).parent('.accordion').find('> *').removeClass('is-active');
          if(currentIsActive != 1) {
            $(this).addClass('is-active');
            $(this).next('.accordion__body').addClass('is-active');
          }
        });