
 // Slider 1
 const slider1 = new Splide("#slider1", {

 gap:15,
   perPage: 3,
   pagination: false,
   arrows: false,
   breakpoints: {
    480: {
      perPage:1,
      pagination: true,
      arrows: false,
    },



     768: {
       perPage: 2,
       pagination: true,
       arrows: false,
     },

     1024: {
      perPage: 2,
      pagination: true,
      arrows: false,
    },
    
  }
 });
 slider1.mount();

 // Slider 2

 const slider2 = new Splide("#slider2", {
  perPage: 4,
  gap:30,
  pagination: true,
  arrows: false,
  breakpoints: {
    480: {
      perPage:1,
      pagination: true,
      arrows: false,
    },



     768: {
       perPage: 2,
       pagination: true,
       arrows: false,
     },

     1024: {
      perPage: 2,
      pagination: true,
      arrows: false,
    },
    
  }
});
slider2.mount();









  // Slider 3
   
   const slider3 = new Splide("#slider3", {
    perPage: 4,
    gap:30,
    pagination: true,
    arrows: false,
    breakpoints: {
      480: {
        perPage:1,
        pagination: true,
        arrows: false,
      },



       768: {
         perPage: 2,
         pagination: true,
         arrows: false,
       },

       1024: {
        perPage: 2,
        pagination: true,
        arrows: false,
      },
      
    }
  });
  slider3.mount();



   // Slider 4
   const slider4 = new Splide("#slider4", {
      perPage: 3,
      gap:30,
      pagination: true,
      arrows: false,
      breakpoints: {
        480: {
          perPage:1,
          pagination: true,
          arrows: false,
        },



         768: {
           perPage: 2,
           pagination: true,
           arrows: false,
         },

         1024: {
          perPage: 2,
          pagination: true,
          arrows: false,
        },
        
      }
    });
    slider4.mount();


       // Slider 5
   const slider5 = new Splide("#slider5", {
    perPage: 1,
    pagination: true,
    arrows: false,
    breakpoints: {
       768: {
         perPage: 1,
         pagination: true,
         arrows: false,
       },
       1366: {
        perPage: 1, // Display all slides without sliding
        pagination: true,
        arrows: false,
      }
    }
  });
  slider5.mount();




  // Slider 7
  const slider7 = new Splide("#slider7", {
    perPage:3,
    gap:30,
    pagination: true,
    arrows: false,
    breakpoints: {
      480: {
        perPage:1,
        pagination: true,
        arrows: false,
      },



       768: {
         perPage: 2,
         pagination: true,
         arrows: false,
       },

       1024: {
        perPage: 2,
        pagination: true,
        arrows: false,
      },
      
    }
  });
  slider7.mount();

 
  

